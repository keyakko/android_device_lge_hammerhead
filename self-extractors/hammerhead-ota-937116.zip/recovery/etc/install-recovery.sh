#!/system/bin/sh
if ! applypatch -c EMMC:/dev/block/platform/msm_sdcc.1/by-name/recovery:9506816:55ebd7ef4996cf902d1d75c4d9e34e807fe6bb41; then
  log -t recovery "Installing new recovery image"
  applypatch -b /system/etc/recovery-resource.dat EMMC:/dev/block/platform/msm_sdcc.1/by-name/boot:8908800:a3bd726fbabaa1dbc2a31e8baf6cb44508177d43 EMMC:/dev/block/platform/msm_sdcc.1/by-name/recovery 55ebd7ef4996cf902d1d75c4d9e34e807fe6bb41 9506816 a3bd726fbabaa1dbc2a31e8baf6cb44508177d43:/system/recovery-from-boot.p
else
  log -t recovery "Recovery image already installed"
fi
